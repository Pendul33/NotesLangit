# Notes Langit

Widget Android sederhana untuk menampilkan dan mengedit satu catatan langsung dari home screen.

## Cara build

1. Buka folder `NotesLangit` di Android Studio.
2. Biarkan Android Studio melakukan Gradle Sync.
3. Pastikan Android SDK 35 terpasang jika diminta.
4. Pilih `Build > Build APK(s)`.
5. Setelah selesai, pilih `locate` untuk menemukan APK debug.
6. Install APK di HP Android.
7. Di home screen, tekan lama area kosong > Widgets > Notes Langit.
8. Taruh widget di home screen.
9. Tap widget untuk menulis/mengubah catatan, lalu tekan **Simpan**.

Catatan disimpan secara lokal di HP menggunakan SharedPreferences.
