package com.langit.notes

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class EditNoteActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val padding = (20 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padding, padding, padding, padding)
        }

        val title = TextView(this).apply {
            text = "📒 Notes Langit"
            textSize = 24f
            setPadding(0, 0, 0, padding / 2)
        }

        val editor = EditText(this).apply {
            hint = "Tulis catatan lu di sini..."
            text = NotesStore.get(this@EditNoteActivity)
            gravity = android.view.Gravity.TOP
            minLines = 10
        }

        val save = Button(this).apply {
            text = "Simpan"
            setOnClickListener {
                NotesStore.set(this@EditNoteActivity, editor.text.toString())
                NotesWidgetProvider.updateAll(this@EditNoteActivity)
                finish()
            }
        }

        layout.addView(title)
        layout.addView(editor, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        layout.addView(save)

        setContentView(layout)
    }
}
