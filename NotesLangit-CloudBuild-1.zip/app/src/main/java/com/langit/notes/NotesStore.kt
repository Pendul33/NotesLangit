package com.langit.notes

import android.content.Context

object NotesStore {
    private const val PREFS = "notes_langit"
    private const val KEY_NOTE = "note"

    fun get(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_NOTE, "") ?: ""

    fun set(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_NOTE, value)
            .apply()
    }
}
